var a = require('./module_one');

console.log(a.foo);
