exports.foo = 'bar'
